<section class="about">
         <div class="container">
           <h2>Get in Touch With Us.</h2>
           <p>Whether you’re interested in working with us or for us, we’re always happy to chat.</p>
           <p style="margin-bottom: 40px;">For Inquiries: <a href="">(500) 123-0800</a>.</p>
           <a href="#" class="drop">DROP US A LINE</a>
         </div>
       </section>