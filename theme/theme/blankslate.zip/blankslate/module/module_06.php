 <section class="pricing" id="pricing">
            <div class="zn-bgSource-imageParallax">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-lg-12">
                            <h3>Pick your plan</h3>
                        </div>
                        <div class="col-md-4 col-lg-4">
                            <div class="pricing-dt">
                                <h2 >
                                    <span style="font-family: Lato;"><span style="color: #c89d28;"><span style="line-height: 19px;"><span style="font-size: 30px; position:relative; top:-35px; ">$</span></span><span style="line-height: 30px;"><span style="font-size: 80px;">59</span></span></span></span>
                                </h2>
                                <h4>Single License</h4>
                                <div class="list-pricing">
                                    <ul>
                                        <li>1 theme included.</li>
                                        <li>1 year of theme updates & support.</li>
                                        <li>20% off future purchases.</li>
                                    </ul>
                                </div>
                                <div class="view">
                                    <a href="#">VIEW</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-lg-4">
                            <div class="pricing-dt">
                                <h2 >
                                    <span style="font-family: Lato;"><span style="color: #c89d28;"><span style="line-height: 19px;"><span style="font-size: 30px; position:relative; top:-35px; ">$</span></span><span style="line-height: 30px;"><span style="font-size: 80px;">399</span></span></span></span>
                                </h2>
                                <h4>Forever Membership</h4>
                                <div class="list-pricing">
                                    <ul>
                                        <li>1 theme included.</li>
                                        <li>1 year of theme updates & support.</li>
                                        <li>20% off future purchases.</li>
                                    </ul>
                                </div>
                                <div class="view">
                                    <a href="#">SIGN UP TODAY</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-lg-4">
                            <div class="pricing-dt">
                                <h2 >
                                    <span style="font-family: Lato;"><span style="color: #c89d28;"><span style="line-height: 19px;"><span style="font-size: 30px; position:relative; top:-35px; ">$</span></span><span style="line-height: 30px;"><span style="font-size: 80px;">199</span></span></span></span>
                                </h2>
                                <h4>1 Year Membership</h4>
                                <div class="list-pricing">
                                    <ul>
                                        <li>All themes included.</li>
                                        <li>1 year of theme updates & support.</li>
                                        <li>20Access all new themes.</li>
                                    </ul>
                                </div>
                                <div class="view">
                                    <a href="#">SIGN UP TODAY</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>           
       </section>