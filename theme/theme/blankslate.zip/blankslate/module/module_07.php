 <section class="lasted-news" id="blog">
           <div class="container">
               <h2>Latest News</h2>
               <div class="row">
                   <div class="col-md-6 col-lg-6">
                       <img src="images/bpost-01-800x800_c.jpg" alt="">
                       <div class="categorry">WORDPRESS</div>
                       <div class="title">
                           <h3>Top 10 Most Popular Premium WordPress Themes of 2017.</h3>
                           <p style="    color: white;
    font-size: 12px;">FEBRUARY 1, 2017 BY <a href="" style="color:#c89d28;">MIHAI</a></p>
                       </div>
                   </div>
                   <div class="col-md-6 col-lg-6">
                       <div class="news">
                           <div class="news-dt">
                             <img src="images/bpost-02-480x280_c.jpg" alt="">
                             <div class="categorry-news" style="text-transform: uppercase;">Graphic Design</div>
                             <div class="title-dt">
                           <h3>A Branding Tool for Everything and Everyone.</h3>
                           <p style="color: black;
    font-size: 12px;">February 21, 2017 by mihai</p>
                       </div>
                           </div>
                           <div class="news-dt">
                             <img src="images/bpost-03-480x280_c.jpg" alt="">
                             <div class="categorry-news" style="text-transform: uppercase;">Create Seo</div>
                             <div class="title-dt">
                           <h3>4 Ways Artificial Intelligence Changes the Game for SEO.</h3>
                           <p style="color: black;
    font-size: 12px;">February 21, 2017 by mihai</p>
                       </div>
                           </div>
                           <div class="news-dt">
                             <img src="images/bpost-04-480x280_c.jpg" alt="">
                             <div class="categorry-news" style="text-transform: uppercase;">Apps</div>
                             <div class="title-dt">
                           <h3>Case Study: 10 Lessons from a Successful Startup.</h3>
                           <p style="color: black;
    font-size: 12px;">February 21, 2017 by mihai</p>
                       </div>
                           </div>
                           <div class="news-dt">
                             <img src="images/bpost-05-480x280_c.jpg" alt="">
                             <div class="categorry-news" style="text-transform: uppercase;">Seo</div>
                             <div class="title-dt">
                           <h3>What You’re Missing with SEO that will Make a World of Difference.</h3>
                           <p style="color: black;
    font-size: 12px;">February 21, 2017 by mihai</p>
                       </div>
                           </div>
                       </div>
                   </div>
                   <div class="button-readmore">
                     <a href="#">READ MORE</a>
                   </div>
               </div>
           </div>
       </section>