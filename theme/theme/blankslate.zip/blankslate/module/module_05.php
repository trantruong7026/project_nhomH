  <section class="video">
           <div class="row">
               <div class="col-md-7 col-lg-7">
                  <div class="">
                     <img src="images/device-b.jpg" alt="">
                  </div>
                  <div class="kl-iconbox eluid105c7ef1 playbutton  kl-iconbox--type-img   kl-iconbox--align-center text-center kl-iconbox--theme-light element-scheme--light" id="eluid105c7ef1">
                    <div class="kl-iconbox__inner clearfix">
                    <div class="kl-iconbox__icon-wrapper ">
                    <img data-toggle="modal" data-target="#exampleModal" class="kl-iconbox__icon" src="images/play-button.png" width="122" height="122" alt="" title="play-button.png"></a>

                     </div>
                    <div class="kl-iconbox__content-wrapper">
                    </div>
                    </div>
                    </div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <button style="text-align: right;" type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      <div class="modal-body" style="padding: 0;">
        <iframe width="100%" height="506" src="https://www.youtube.com/embed/e452W2Kj-yg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </div>
    </div>
  </div>
</div>


               </div>
               <div class="col-md-5 col-lg-5">
                  <div class="text-video">
                       <h3>Look like an expert right from the start.</h3>
                   <p>Get all our proffesional themes.</p>
                  </div>
                  <div class="icon-video">
                    <div class="icon-text">
                        <img src="images/icon1.png" alt="">
                        <div class="title">
                            <h4>Stunning Page Builder</h4>
                            <p>Intrinsicly formulate scalable web services before fully researched methodologies.</p>
                        </div>
                    </div>
                    <div class="icon-text">
                        <img src="images/icon2.png" alt="">
                        <div class="title">
                            <h4>Iconic Awarded Design</h4>
                            <p>Intrinsicly formulate scalable web services before fully researched methodologies.</p>
                        </div>
                    </div>
                    <div class="icon-text">
                        <img src="images/icon6.png" alt="">
                        <div class="title">
                            <h4>eCommerce Ready</h4>
                            <p>Intrinsicly formulate scalable web services before fully researched methodologies.</p>
                        </div>
                    </div>
                    <div class="icon-button">
                        <a href="#" style="    padding: 20px 60px;
    background: #e5e1e1;
    border-radius: 40px;color: black;font-size: 13px;font-weight: 600;">START NOW</a>
                    </div>
                  </div>
               </div>
           </div>
       </section>