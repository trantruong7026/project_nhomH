<section class="covered" id="services">
         <div class="container">
           <div class="row">
             <div class="col-md-4 col-lg-4">
               <h2>We've got you covered.</h2>
               <p>Intuitive drag and drop Page Builder. Stunning themes. Over 100 Elements. Creating your beautiful website has never been easier.</p>
             </div>
              <div class="col-md-4 col-lg-4">
                <div class="icon-text">
                        <img src="images/icon1.png" alt="">
                        <div class="title">
                            <h4>Stunning Page Builder</h4>
                            <p>Setup pages and content like a PRO. Coding is not required and a handy documentation is included.</p>
                        </div>
                  </div>
                  <div class="icon-text">
                        <img src="images/icon3.png" alt="">
                        <div class="title">
                            <h4>Featurewise Complete</h4>
                            <p>Without a doubt, Kallyas is one of the most complete WordPress themes on the market, being packed with all the goodies and sweet gems.</p>
                        </div>
                  </div>
                  <div class="icon-text">
                        <img src="images/icon5.png" alt="">
                        <div class="title">
                            <h4>Rescue support</h4>
                            <p>In time, gathering awesome feedback from our loyal customers, Kallyas became a mature, stable and future-proof project.</p>
                        </div>
                  </div>
              </div>
               <div class="col-md-4 col-lg-4">
                 <div class="icon-text">
                        <img src="images/icon2.png" alt="">
                        <div class="title">
                            <h4>Iconic Awarded Design</h4>
                            <p>This design is featured across the marketplaces and awarded for it's looks. Walkthrough and enjoy the visuals.</p>
                        </div>
                  </div>
                  <div class="icon-text">
                        <img src="images/icon4.png" alt="">
                        <div class="title">
                            <h4>Featurewise CoMature Project</h4>
                            <p>In time, gathering awesome feedback from our loyal customers, Kallyas became a mature, stable and future-proof project.</p>
                        </div>
                  </div>
                  <div class="icon-text">
                        <img src="images/icon6.png" alt="">
                        <div class="title">
                            <h4>e-Commerce Ready</h4>
                            <p>In time, gathering awesome feedback from our loyal customers, Kallyas became a mature, stable and future-proof project.</p>
                        </div>
                  </div>
               </div>
           </div>
         </div>
       </section>