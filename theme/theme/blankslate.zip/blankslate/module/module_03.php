  <section class="businesses" id="about">
        <div class="container">
             <h3>We craft ecosystems that grow businesses.</h3>
         <p>We're a full-service digital agency that believes being a Favorite brand is more valuable than just being a Famous one. We craft beautifully useful, connected ecosystems that grow businesses and build enduring relationships between brands and humans.</p>
         <div class="row">
             <div class="col-md-4 col-lg-4">
                 <img src="images/thumbnail-1.jpg">
                <div class="content">
                    <h3>User experience</h3>
                    <p>Update your online business experience to 2017 standards. Encrease your earnings.</p>
                </div>
             </div>
             <div class="col-md-4 col-lg-4">
                 <img src="images/thumbnail-2.jpg">
                <div class="content">
                    <h3>Social Media</h3>
                    <p>Update your online business experience to 2017 standards. Encrease your earnings.</p>
                </div>
             </div>
             <div class="col-md-4 col-lg-4">
                 <img src="images/thumbnail-3.jpg">
                <div class="content">
                    <h3>Branding</h3>
                    <p>Update your online business experience to 2017 standards. Encrease your earnings.</p>
                </div>
             </div>
         </div>
        </div>
     </section> 