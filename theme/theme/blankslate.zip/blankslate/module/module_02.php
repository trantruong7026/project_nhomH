 <section class=" banner">
        <div class="container banner-title">
            <h2>Membership <br> Business Model.</h2>
        <p>Get access to 200+ Premium WP Themes .</p>
        <a href="#">START NOW</a>
        </div>
    </section>