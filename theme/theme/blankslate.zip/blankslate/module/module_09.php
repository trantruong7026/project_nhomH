 <section class="facts">
         <div class="container">
           <div class="row">
             <div class="col-md-12 col-lg-12">
               <h2>Facts</h2>
             </div>
             <div class="col-md-12 col-lg-12">
               <div id="projectFacts" class="sectionClass">
                  <div class="fullWidth eight columns">
                     <div class="projectFactsWrap ">
                        <div class="item wow fadeInUpBig animated animated" data-number="12">
                           <i class="fa fa-briefcase"></i>
                           <p id="number1" class="number">12</p>
                           <span></span>
                           <p>Projects done</p>
                        </div>
                        <div class="item wow fadeInUpBig animated animated" data-number="55">
                           <i class="fa fa-smile-o"></i>
                           <p id="number2" class="number">55</p>
                           <span></span>
                           <p>Happy professors</p>
                        </div>
                        <div class="item wow fadeInUpBig animated animated" data-number="359">
                           <i class="fa fa-coffee"></i>
                           <p id="number3" class="number">359</p>
                           <span></span>
                           <p>Techie Students</p>
                        </div>
                        <div class="item wow fadeInUpBig animated animated" data-number="246">
                           <i class="fa fa-camera"></i>
                           <p id="number4" class="number">100</p>
                           <span></span>
                           <p>Alumini survey</p>
                        </div>
                     </div>
                  </div>
               </div>
             </div>
             <div class="col-md-12 col-lg-12">
               <h3>We craft beautifully useful marketing and digital products that grow businesses. </h3>
             </div>
           </div>
         </div>
       </section>