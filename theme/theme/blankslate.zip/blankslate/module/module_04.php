 <section class="history">
           <div class="row" id="row">
             <div class="col-md-4 col-lg-4">
                <div class="content-history">
                    <h3>History</h3>
                    <p>Add as many language packs as you want, to showcase your website across the entire globe.</p>
                </div>
             </div>
             <div class="col-md-4 col-lg-4">
                 <img src="images/thumbnail-4.jpg">
             </div>
             <div class="col-md-4 col-lg-4">
                <div class="content-history">
                    <h3>Who we are</h3>
                    <p>Add as many language packs as you want, to showcase your website across the entire globe.</p>
                </div>
             </div>
         </div>

         <div class="row" id="row1">
             <div class="col-md-8 col-lg-8">
              <div class="row">
                  <div class="col-md-6 col-lg-6">
                       <img src="images/thumbnail-5.jpg">
                  </div>
                  <div class="col-md-6 col-lg-6">
                        <div class="content-history">
                    <h3>What we do</h3>
                    <p>Add as many language packs as you want, to showcase your website across the entire globe.</p>
                </div>
                  </div>
              </div>
               <div class="row" id="row2">
                  <div class="col-md-6 col-lg-6">
                    <div class="content-history">
                    <h3>Awards</h3>
                    <p>Add as many language packs as you want, to showcase your website across the entire globe.</p>
                     </div>
                      
                  </div>
                  <div class="col-md-6 col-lg-6">
                        <img src="images/illustration2.png">
                  </div>
              </div>
             </div>
             <div class="col-md-4 col-lg-4" id="zn-bgSource-image">
                 <div class="content-history" style="padding-top: 100%;">
                    <h3>Awards</h3>
                    <p>Add as many language packs as you want, to showcase your website across the entire globe.</p>
                     </div>
             </div>
         </div>
       </section>