 <section class="partner">
         <div class="container">
           <div class="slider-partner">
             <h2>Working with world's best companies.</h2>
             <div class="row">
               <div class="col-2dot4">
                 <<img src="images/logo-horse.png" alt="">
               </div>
               <div class="col-2dot4">
                 <<img src="images/logo-crown.png" alt="">
               </div>

               <div class="col-2dot4">
                 <<img src="images/logo-cupcake.png" alt="">
               </div>
               <div class="col-2dot4">
                 <<img src="images/logo-frank.png" alt="">
               </div>
               <div class="col-2dot4">
                 <<img src="images/logo-ship.png" alt="">
               </div>
             </div>
           </div>
         </div>
       </section>